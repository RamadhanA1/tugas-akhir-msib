<main id="main" class="main">

    <div class="pagetitle">
      <h1>Home</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Staff</a></li>
          <li class="breadcrumb-item active">Home</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <div class="d-flex align-items-center" style="height: 70vh; width:100%;">
      <div>
        <h1>Selamat Datang 'Staff CompStore'</h1>
        <h2>Di Sistem Informasi CompStore</h2>
      </div>
      
    </div>
    

  </main><!-- End #main -->